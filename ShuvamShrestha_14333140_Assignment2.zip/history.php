<?php include 'header.php' ?>

<?php include 'navigation.php' ?>

<?php include 'renter.php' ?>

<?php include 'footer.php' ?>