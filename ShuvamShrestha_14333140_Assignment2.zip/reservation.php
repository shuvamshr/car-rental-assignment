<?php include 'header.php' ?>

<?php include 'navigation.php' ?>

<?php include 'cart.php' ?>

<?php include 'order.php' ?>

<?php include 'footer.php' ?>