<?php include 'header.php' ?>

<?php include 'navigation.php' ?>

<?php include 'vehicle.php' ?>

<?php include 'footer.php' ?>